<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-10">
                        <div class="card">
                            <div class="card-header ">
                                Évènnement <strong><?php echo e($event->abbreviation); ?></strong> / Ajouter Un Sponsor
                            </div>
                            <form action="<?php echo e(route('sponsors.addSponsor', [$event->id])); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                                <?php echo csrf_field(); ?>
                                <div class="card-body card-block ">

                                    <div class="row form-group">
                                        <div class="col col-md-3">

                                            <label for="title" class=" form-control-label"> Sélectionnez le logo du sponsor</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input id="sponsors" name="sponsors[]" class="form-control-file"
                                                   type="file" value="<?php echo e(old('sponsors[]')); ?>" accept="image/jpeg,image/png,image/jpg">
                                            <?php for($i = 0; $i < 5; $i++): ?>
                                                <?php if($errors->any('sponsors.'.$i)): ?>
                                                    <small class="form-text status--denied"><?php echo e($errors->first('sponsors.'.$i)); ?></small>
                                                    <?php break; ?>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                            <?php if($errors->any('sponsors')): ?>
                                                <small class="form-text status--denied"><?php echo e($errors->first('sponsors')); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col col-md-3">

                                            <label for="title" class=" form-control-label"> Sélectionnez le logo du sponsor</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input id="name" name="name" class="form-control" type="text" value="<?php echo e(old('name')); ?>">
                                            <?php if($errors->any('name')): ?>
                                                <small class="form-text status--denied"><?php echo e($errors->first('name')); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div  class="pull-right" style="padding-bottom:  2%;padding-right: 2%">
                                    <div>
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="zmdi zmdi-dot-circle-o"></i> Ajouter
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="zmdi zmdi-ban"></i> Annuler
                                        </button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>