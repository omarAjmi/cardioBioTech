<section class="pb100">
    <div class="container" id="speakers">
        <div class="section_title mb50">
            <h3 class="title">
                Comité
            </h3>
        </div>
    </div>
    <div class="row justify-content-center no-gutters">
        <?php $__currentLoopData = $event->commitee->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6">
                <div class="speaker_box">
                    <div class="speaker_img">
                        <img src="<?php echo e($member->data->photo); ?>" alt="speaker name">
                        <div class="info_box">
                            <h5 class="name"><?php echo e($member->data->getFullName()); ?></h5>
                            <p class="position">CEO Company</p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>