<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">                    
                    <div class="col-lg-10">
                        <div class="card">
                            <div class="card-header ">
                                Évènnement <strong><?php echo e($event->abbreviation); ?></strong> / Ajouter Des Images
                            </div>
                             <form action="<?php echo e(route('galleries.addImages', [$event->id])); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                                    <?php echo csrf_field(); ?>
                            <div class="card-body card-block ">
                                    
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            
                                              <label for="title" class=" form-control-label"> Sélectionnez les images d'événement</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input id="files" name="files[]" multiple="" class="form-control-file"
                                                type="file" value="<?php echo e(old('files[]')); ?>" accept="image/jpeg,image/png,image/jpg">
                                            <?php for($i = 0; $i < 5; $i++): ?>
                                                <?php if($errors->any('files.'.$i)): ?>
                                                    <small class="form-text status--denied"><?php echo e($errors->first('files.'.$i)); ?></small>
                                                    <?php break; ?>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                            <?php if($errors->any('files')): ?>
                                                <small class="form-text status--denied"><?php echo e($errors->first('files')); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                     </div>
                                     <hr>
                                    <div  class="pull-right" style="padding-bottom:  2%;padding-right: 2%">
                                        <div>
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="zmdi zmdi-dot-circle-o"></i> Creer une Gallerie
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="zmdi zmdi-ban"></i> Annuler
                                        </button>
                                    </div>
                                    </div>
                                </form>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>