<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <?php if(Session::has('success')): ?>
                    <div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
                        <span class="badge badge-pill badge-success">Succée</span>
                        <?php echo e(Storage::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
                <?php if($commitees->isEmpty()): ?>
                <div class="alert alert-info"> <strong>Info!</strong> pas de commitees</div>
                <?php else: ?>
                <div class="">
        
                            <div class="table-responsive table-responsive-data2 ">
                                
                                <table class="table table-data2">
                                    <div class="card">
                                    <thead class="card-header">
                                    <tr>
                                        <th>Date</th>
                                        <th>évènnement</th>
                                        <th>totale</th>
                                        <th>membres</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $commitees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($com->created_at->diffForHumans()); ?></td>
                                            <td><?php echo e($com->event->abbreviation); ?></td>
                                            <td><?php echo e($com->members->count()); ?></td>
                                            <td><a href="<?php echo e(route('commitees.members', [$com->id])); ?>">membres</a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
    
                <?php endif; ?>
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>