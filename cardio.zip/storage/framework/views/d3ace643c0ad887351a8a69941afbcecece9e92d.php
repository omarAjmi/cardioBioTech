<section class="pt100 pb100">
    <div class="container">
        <div class="section_title">
            <h3 class="title">
                À propos
            </h3>
        </div>
        <div class="row justify-content-center">
            <?php if(!is_null($event->about)): ?>
                <?php $__currentLoopData = $event->breakLongAbout(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-12">
                        <p><?php echo e($p); ?></p> <br>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-md-6 col-12">
                    <p>Non disponible</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>