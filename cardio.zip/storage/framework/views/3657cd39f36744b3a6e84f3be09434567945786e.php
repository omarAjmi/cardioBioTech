<!-- MENU SIDEBAR-->
<aside class="menu-sidebar d-none d-lg-block">
    <div class="logo">
        <a href="<?php echo e(route('admin')); ?>">
            <h3 style= " font-family: Times New Roman; font-style: normal;"><img src="/img/card_logo.png" alt="Cool Admin" style="width: 30%" />
            Cardiobiotec</h3>
        </a>
    </div>
    <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
            <ul class="list-unstyled navbar__list">
                <li>
                    <a href="<?php echo e(route('admin')); ?>"><i class="fas fa-bars"></i>Évènnements</a>
                </li>
                <?php if($events->isNotEmpty()): ?>
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class=" has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-folder"></i><?php echo e($event->abbreviation); ?></a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="<?php echo e(route('participations', $event->id)); ?>"><i class="fas fa-handshake"></i>Participations</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('galleries.preview', $event->id)); ?>"><i class="fas fa-picture-o"></i>Gallerie</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('commitees.preview', $event->id)); ?>"><i class="fas fa-users"></i>Comité</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('sponsors.preview', $event->id)); ?>"><i class="fas fa-money-bill-alt"></i>Sponsors</a>
                                </li>
                            </ul>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</aside>
<!-- END MENU SIDEBAR-->
