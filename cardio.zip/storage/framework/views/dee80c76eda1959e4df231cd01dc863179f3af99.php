<?php $__env->startSection('content'); ?>
    <!--page title section-->
    <section class="inner_cover parallax-window" data-parallax="scroll" style="background-image: url(/img/bg/img.png)" >
        <div class="overlay_dark"></div>
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-12">
                    <div class="inner_cover_content">
                        <h3>
                            <?php echo e($event->abbreviation); ?>

                        </h3>
                    </div>
                </div>
            </div>
    
            <div class="breadcrumbs">
                <ul>
                    <li><a href="<?php echo e(route('welcome')); ?>">Acceuil</a> | </li>
                    <li><span>Événements</span></li>
                </ul>
            </div>
        </div>
    </section>
    <!--page title section end-->
    
    <div id="galery" style="margin-top: 5%">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <!-- galery owl -->
                <div id="galery-owl" class="owl-carousel owl-theme">
                    <?php if($event->gallery->album->isNotEmpty()): ?>

                        <?php $__currentLoopData = $event->gallery->album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- galery item -->
                            <div class="galery-item">
                                <img src="<?php echo e($image->path); ?>" >
                            </div>
                            <!-- /galery item -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>

                        <?php $__currentLoopData = $event->sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- galery item -->
                            <div class="galery-item" >
                                <img src="<?php echo e($slider->name); ?>"  >
                            </div>
                            <!-- /galery item -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
    
                </div>
                <!-- /galery owl -->
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!--event info -->
    <section class="pt100 ">
        <div class="container">
            <h1 style="text-align: center;color: #005792"><?php echo e($event->title); ?></h1>
            <div class="row justify-content-center">
                <div class="col-6 col-md-3  ">
                    <div class="icon_box_two">
                        <i class="ion-ios-calendar-outline"></i>
                        <div class="content">
                            <h6 class="box_title">
                                DATE
                            </h6>
                            <p class="row justify-content-center">
                                <?php if(!is_null($event)): ?>
                                    <?php echo e($event->start_date->format('l j F Y H:i:s')); ?>

                                    <?php if($event->start_date->diffInDays($event->end_date) > 0): ?>
                                        (<?php echo e($event->start_date->diffInDays($event->end_date)); ?>) jours
                                    <?php endif; ?>
                                <?php endif; ?>

                            </p>
                        </div>
                    </div>
                </div>
    
                <div class="col-6 col-md-3  ">
                    <div class="icon_box_two">
                        <i class="ion-ios-location-outline"></i>
                        <div class="content">
                            <h6 class="box_title">
                                locale
                            </h6>
                            <p class="row justify-content-center">
                                <?php if(!is_null($event)): ?>
                                    <?php echo e($event->address->state); ?>,
                                    <?php echo e($event->address->city); ?> <br>
                                    <?php echo e($event->address->street); ?>

                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
    
                <div class="col-6 col-md-3  ">
                    <div class="icon_box_two">
                        <i class="ion-ios-person-outline"></i>
                        <div class="icon_box_two">
                            <i class="ion-ios-person-outline"></i>
                            <div class="content">
                                <h6 class="box_title">
                                    Organisateur
                                </h6>
                                <p class="row justify-content-center">
                                    <?php if(!is_null($event)): ?><?php echo e($event->organiser); ?><?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3  ">
                    <div class="icon_box_two">
                        <i class="ion-ios-calendar-outline"></i>
                        <div class="content">
                            <h6 class="box_title">
                                dernière date des participations
                            </h6>
                            <p class="row justify-content-center">
                                <?php if(!is_null($event)): ?>
                                    <?php echo e($event->start_date->format('l j F Y H:i:s')); ?><br>
                                <?php endif; ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--events section -->

    <!--about the event -->
    <?php echo $__env->make('public.partials.about', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--about the event end -->
    <!--speaker section-->
    <?php if($event->commitee->members->isNotEmpty()): ?>
        <?php echo $__env->make('public.partials.commitee', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <!--flyer section end -->
    <?php echo $__env->make('public.partials.flyer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--flyer section end -->
        <?php if($event->dead_line > now()): ?>
                <div class="container">
                    <div class="section_title">
                        <h3 class="title">
                        Participation
                        </h3>
                    </div>      
                    <div >
                        <div class="row justify-content-center" id="participation">      
                            <div class="col-md-6 col-12">
                                <p>
                                    pour la participation, merci de télécharger <i style="color: dodgerblue" class="fa fa-download"></i>
                                    <a href="<?php echo e(route('downloadFileEvent', ['id'=>$event->id,'filename'=>$event->getProgramFileName()])); ?>">
                                        <b><u>ce fichier</u></b>
                                    </a> formel, de lui fournir avec les données nécessaires puis de le renvoyer à l’aide de ce formulaire.
                                </p>
                                    <?php if(!is_null($participation)): ?>
                                    <p>
                                        Vous avez déjà souscrits,  et <?php if($participation->confirmation): ?>
                                                                            votre demande est confirmée
                                                                      <?php else: ?>
                                                                            votre demande est en cours d'être examiner par le comité organisateur
                                                                      <?php endif; ?>
                                        <br> si vous voulez vous pouvez mettre a jour votre demande de participaion
                                    </p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 col-12">
                                <form class="contact_form" method="POST" action="<?php echo e(route('events.participate', [$event->id])); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php if(!is_null($participation)): ?>
                                        <div class="form-group">
                                            <input type="text" class="form-control <?php if($errors->first('title')): ?>
                                                is-invalid
<?php endif; ?>" name="title" placeholder="Titre De Participation" value="<?php echo e($participation->title); ?>">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control
                                                                                    <?php if($errors->first('title')): ?>
                                                is-invalid
<?php endif; ?>" name="affiliation" placeholder="Affiliation" value="<?php echo e($participation->affiliation); ?>">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control <?php if($errors->first('authors')): ?>
                                                is-invalid
<?php endif; ?>" name="authors" placeholder="Autheurs" value="<?php echo e($participation->authors); ?>">
                                        </div>
                                    <?php else: ?>
                                        <div class="form-group">
                                            <input type="text" class="form-control
                                                                                <?php if($errors->first('title')): ?>
                                                                                    is-invalid
                                                                                <?php endif; ?>" name="title" placeholder="Titre De Participation">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control
                                                                                    <?php if($errors->first('affiliation')): ?>
                                                                                        is-invalid
                                                                                    <?php endif; ?>" name="affiliation" placeholder="Affiliation">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control <?php if($errors->first('authors')): ?>
                                                                                        is-invalid
                                                                                    <?php endif; ?>" name="authors" placeholder="Autheurs">
                                        </div>
                                    <?php endif; ?>
                                    <div class="form-group">
                                        <input type="file" accept="application/pdf" class="form-control" name="participation" placeholder="Format De Participation">
                                    
                                        <button class="btn btn-rounded btn-primary " type="submit"><i class="fa fa-plus-circle"></i> Déposer</button>
                                    </div>

                                </form> 
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
    <!--event section end -->

    <!--sponsors section end -->
    <?php if($event->sponsors->isNotEmpty()): ?>
        <?php echo $__env->make('public.partials.sponsors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <!--sponsors section end-->

    <?php if(Session::has('partSuccess')): ?>
        <div class="modal fade show" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" data-backdrop="static" style="display: block; padding-left: 15px;">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="staticModalLabel">Succès</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>
                            <?php echo e(Session::get('partSuccess')); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    <?php elseif(Session::has('partFail')): ?>
        <div class="modal fade show" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" data-backdrop="static" style="display: block; padding-left: 15px;">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="staticModalLabel">Violation a eu lieu</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>
                            <?php if(Session::get('partFail')==='*'): ?>
                                Fichier requis doit être de type pdf ou docx
                            <?php else: ?>
                                <?php echo e(Session::get('partFail')); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>