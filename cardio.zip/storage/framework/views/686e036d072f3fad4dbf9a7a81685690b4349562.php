
<!--header start here -->
<header class="header navbar fixed-top navbar-expand-md">
    <div class="container">
        <a class="navbar-brand logo" href="<?php echo e(route('welcome')); ?>">
            <img src="/img/logo-white.png" alt="Evento" />
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#headernav" aria-expanded="false"
                aria-label="Toggle navigation">
            <span class="lnr lnr-text-align-right"></span>
        </button>
        <div class="collapse navbar-collapse flex-sm-row-reverse" id="headernav">
            <ul class=" nav navbar-nav menu">
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('welcome')); ?>">Accueil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="<?php echo e(route('welcome')); ?>#speakers">Comité</a>
                </li>
                <li class="nav-item">
                    <div class="dropdown">
                        <a class="nav-link " href="#">Évènements</a>
                        <div class="dropdown-content">
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('event', [$event->id])); ?>"><?php echo e($event->abbreviation); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="<?php echo e(route('contact')); ?>">Contactez nous</a>
                </li>
                <?php if(Auth::check()): ?>
                    <li class="nav-item">
                        <div class="dropdown">
                            <a class="nav-link " href="#"><b><?php echo e(Auth::user()->getFullName()); ?></b>
                                <img src="<?php echo e(Auth::user()->photo); ?>" alt=" logo" style="height: 30px;width: 30px;border-radius: 50%;">
                            </a>
                            <div class="dropdown-content">
                                <a href="<?php echo e(route('profile', [Auth::id()])); ?>">profile</a>
                                <?php if(Auth::user()->admin): ?>
                                    <a href="<?php echo e(route('admin')); ?>">Site Admin</a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                    Se Déconnecter
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link " href="#" data-toggle="modal" data-target="#myModal">Se connecter</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</header>
