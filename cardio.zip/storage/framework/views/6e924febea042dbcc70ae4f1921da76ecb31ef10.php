<?php $__env->startSection('content'); ?>
    <!--cover section slider -->
    <section id="home" class="home-cover">
        <?php if($events->isNotEmpty()): ?>
            <div class="cover_slider owl-carousel owl-theme">
                <?php $__currentLoopData = $event->sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cover_item" style="background: url('<?php echo e($slider->name); ?>');">
                        <div class="slider_content">
                            <div class="slider-content-inner">
                                <div class="container">
                                    <div class="slider-content-center">
                                        <h2 class="cover-title">
                                            <?php echo e($event->title); ?>

                                        </h2>
                                        <strong class="cover-xl-text"><?php echo e($event->abbreviation); ?></strong>
                                        <p class="cover-date">
                                            <?php echo e($event->start_date->format('l j F Y H:i:s')); ?>

                                        </p>
                                        <a href="<?php echo e(route('event',[$event->id])); ?>" class=" btn btn-primary btn-rounded">
                                            prendre part
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="cover_nav">
                <ul class="cover_dots">
                    <li class="active" data="0"><span>1</span></li>
                    <?php for($i = 1; $i <= $event->sliders->count(); $i++): ?>
                        <li data="<?php echo e($i); ?>"><span><?php echo e($i+1); ?></span></li>
                    <?php endfor; ?>
                </ul>
            </div>
        <?php else: ?>
            <div class="cover_slider owl-carousel owl-theme">
                <div class="cover_item" style="background: url('/img/bg/background01.jpg');">
                    <div class="slider_content">
                        <div class="slider-content-inner">
                            <div class="container">
                                <div class="slider-content-center">
                                    <h2 class="cover-title">
                                        Prepare yourself for the
                                    </h2>
                                    <strong class="cover-xl-text">conference</strong>
                                    <p class="cover-date">
                                        12-14 February 2018 - Los Angeles, CA.
                                    </p>
                                    <a href="#" class=" btn btn-primary btn-rounded">
                                        Buy Tickets Now
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="cover_nav">
                <ul class="cover_dots">
                    <li class="active" data="0"><span>1</span></li>
                    <li data="1"><span>2</span></li>
                    <li data="2"><span>3</span></li>
                </ul>
            </div>
        <?php endif; ?>
    </section>
    <!--cover section slider end -->
    
    <?php if(is_null($event)): ?>
        <h5>Pas des évènnements actuellèment</h5>
    <?php else: ?>
        <!--event info -->
        <section class="pt100 pb100">
            <div class="container">
                <h1 style="text-align: center;color: #005792"><?php if(!is_null($event)): ?><?php echo e($event->title); ?><?php endif; ?></h1>
                <div class="row justify-content-center">
                    <div class="col-md-3  ">
                        <div class="icon_box_two">
                            <i class="ion-ios-calendar-outline"></i>
                            <div class="content">
                                <h6 class="box_title">
                                    DATE
                                </h6>
                                <p class="row justify-content-center">
                                    <?php if(!is_null($event)): ?>
                                        <?php echo e($event->start_date->format('l j F Y H:i:s')); ?>

                                        <?php if($event->start_date->diffInDays($event->end_date) > 0): ?>
                                            (<?php echo e($event->start_date->diffInDays($event->end_date)); ?>) jours
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                </p>
                            </div>
                        </div>
                    </div>
        
                    <div class="col-md-3  ">
                        <div class="icon_box_two">
                            <i class="ion-ios-location-outline"></i>
                            <div class="content">
                                <h6 class="box_title">
                                    locale
                                </h6>
                                <p class="row justify-content-center">
                                    <?php if(!is_null($event)): ?>
                                        <?php echo e($event->address->state); ?>,
                                        <?php echo e($event->address->city); ?> <br>
                                        <?php echo e($event->address->street); ?>

                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
        
                    <div class="col-md-3  ">
                        <div class="icon_box_two">
                            <i class="ion-ios-person-outline"></i>
                            <div class="content">
                                <h6 class="box_title">
                                    Organisateur
                                </h6>
                                <p class="row justify-content-center">
                                    <?php if(!is_null($event)): ?><?php echo e($event->organiser); ?><?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3  ">
                        <div class="icon_box_two">
                            <i class="ion-ios-calendar-outline"></i>
                            <div class="content">
                                <h6 class="box_title">
                                    dernière date des participations
                                </h6>
                                <p class="row justify-content-center">
                                    <?php if(!is_null($event)): ?>
                                        <?php echo e($event->start_date->format('l j F Y H:i:s')); ?><br>
                                    <?php endif; ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--event info end -->
        
        
        <!--event countdown -->
        <?php if(!is_null($event)): ?>
            <section class="bg-img pt70 pb70" style="background-image: url('/img/bg/img.png');">
                <div class="overlay_dark"></div>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-12 col-md-10">
                            <h4 class="mb30 text-center color-light">Compteur jusqu'au grand événement</h4>
                            <div class="countdown"></div>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        <!--event count down end-->
        
        <!--about the event -->
        <?php if(!is_null($event)): ?>
            <?php echo $__env->make('public.partials.about', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
        <!--about the event end -->
        <!--speaker section-->
        <?php if(!is_null($event) and $event->commitee->members->isNotEmpty()): ?>
            <?php echo $__env->make('public.partials.commitee', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
        <!--flyer section end -->
        <?php if(!is_null($event)): ?>
            <?php echo $__env->make('public.partials.flyer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
        <!--flyer section end -->
        <?php if(!is_null($event) and $event->sponsors->isNotEmpty()): ?>
            <?php echo $__env->make('public.partials.sponsors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
        <!--flyer section end-->
        <?php echo $__env->make('public.partials.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>