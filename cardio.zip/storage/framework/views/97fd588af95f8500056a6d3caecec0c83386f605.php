<?php $__env->startSection('content'); ?>
    <!--cover section slider -->
    <section id="home" class="home-cover">
        <?php if($events->isNotEmpty()): ?>
            <div class="cover_slider owl-carousel owl-theme">
                <?php $__currentLoopData = $events->first()->sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cover_item" style="background: url('<?php echo e($slider->name); ?>');">
                        <div class="slider_content">
                            <div class="slider-content-inner">
                                <div class="container">
                                    <div class="slider-content-center">
                                        <h2 class="cover-title">
                                            <?php echo e($events->first()->title); ?>

                                        </h2>
                                        <strong class="cover-xl-text"><?php echo e($events->first()->abbreviation); ?></strong>
                                        <p class="cover-date">
                                            <?php echo e($events->first()->start_date->format('l j F Y H:i:s')); ?>

                                        </p>
                                        <a href="<?php echo e(route('event',[$events->first()->id])); ?>" class=" btn btn-primary btn-rounded">
                                            prendre part
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="cover_nav">
                <ul class="cover_dots">
                    <li class="active" data="0"><span>1</span></li>
                    <?php for($i = 1; $i <= $events->first()->sliders->count(); $i++): ?>
                        <li data="<?php echo e($i); ?>"><span><?php echo e($i+1); ?></span></li>
                    <?php endfor; ?>
                </ul>
            </div>
        <?php else: ?>
            <div class="cover_slider owl-carousel owl-theme">
                <div class="cover_item" style="background: url('/img/bg/background01.jpg');">
                    <div class="slider_content">
                        <div class="slider-content-inner">
                            <div class="container">
                                <div class="slider-content-center">
                                    <h2 class="cover-title">
                                        Prepare yourself for the
                                    </h2>
                                    <strong class="cover-xl-text">conference</strong>
                                    <p class="cover-date">
                                        12-14 February 2018 - Los Angeles, CA.
                                    </p>
                                    <a href="#" class=" btn btn-primary btn-rounded">
                                        Buy Tickets Now
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="cover_nav">
                <ul class="cover_dots">
                    <li class="active" data="0"><span>1</span></li>
                    <li data="1"><span>2</span></li>
                    <li data="2"><span>3</span></li>
                </ul>
            </div>
        <?php endif; ?>
    </section>
    <!--cover section slider end -->
    
    <?php if($events->isEmpty()): ?>
        <h5>Pas des évènnements actuellèment</h5>
    <?php else: ?>
        <!--event info -->
        <section class="pt100 pb100">
            <div class="container">
                <h1 style="text-align: center;color: #005792"><?php if(!is_null($events->first())): ?><?php echo e($events->first()->title); ?><?php endif; ?></h1>
                <div class="row justify-content-center">
                    <div class="col-6 col-md-3  ">
                        <div class="icon_box_two">
                            <i class="ion-ios-calendar-outline"></i>
                            <div class="content">
                                <h5 class="box_title">
                                    DATE
                                </h5>
                                <p>
                                    <?php if(!is_null($events->first())): ?>
                                        <?php echo e($events->first()->start_date->format('l j F Y H:i:s')); ?><br>
                                        <?php if($events->first()->start_date->diffInDays($events->first()->end_date) > 0): ?>
                                            (<?php echo e($events->first()->start_date->diffInDays($events->first()->end_date)); ?>) jours
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                </p>
                                    
                            </div>
                        </div>
                    </div>
        
                    <div class="col-6 col-md-3  ">
                        <div class="icon_box_two">
                            <i class="ion-ios-location-outline"></i>
                            <div class="content">
                                <h5 class="box_title">
                                    locale
                                </h5>
                                <p>
                                    <?php if(!is_null($events->first())): ?><?php echo e($events->first()->address->state); ?><?php endif; ?>, 
                                    <?php if(!is_null($events->first())): ?><?php echo e($events->first()->address->city); ?><?php endif; ?> <br>
                                    <?php if(!is_null($events->first())): ?><?php echo e($events->first()->address->street); ?><?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
        
                    <div class="col-6 col-md-3  ">
                        <div class="icon_box_two">
                            <i class="ion-ios-person-outline"></i>
                            <div class="content">
                                <h5 class="box_title">
                                    Organisateur
                                </h5>
                                <p>
                                    <?php if(!is_null($events->first())): ?><?php echo e($events->first()->organiser); ?><?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--event info end -->
        
        
        <!--event countdown -->
        <section class="bg-img pt70 pb70" style="background-image: url('/img/bg/img.png');">
            <div class="overlay_dark"></div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-md-10">
                        <h4 class="mb30 text-center color-light">Compteur jusqu'au grand événement</h4>
                        <div class="countdown"></div>
            </div>
        </section>
        <!--event count down end-->
        
        
        <!--about the event -->
        <section class="pt100 pb100">
            <div class="container">
                <div class="section_title">
                    <h3 class="title">
                        À propos
                    </h3>
                </div>
                <div class="row justify-content-center">
                    <?php if($events->isNotEmpty()): ?>
                        <?php $__currentLoopData = $events->first()->breakLongAbout(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-12">
                                <p><?php echo e($p); ?></p> <br>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col-md-6 col-12">
                            <p>Non disponible</p>
                        </div>
                    <?php endif; ?>
                </div>
        
                <!--event features-->
                
                <!--event features end-->
            </div>
        </section>
        <!--about the event end -->
        
        
        <!--speaker section-->
        <section class="pb100">
            <div class="container" id="speakers">
                <div class="section_title mb50">
                    <h3 class="title">
                        Comité
                    </h3>
                </div>
            </div>
            <div class="row justify-content-center no-gutters">
                <?php if($events->isNotEmpty() and !is_null($events->first()->commitee)): ?>
                    <?php $__currentLoopData = $events->first()->commitee->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-sm-6">
                            <div class="speaker_box">
                                <div class="speaker_img">
                                    <img src="<?php echo e($member->data->photo); ?>" alt="speaker name">
                                    <div class="info_box">
                                        <h5 class="name"><?php echo e($member->data->getFullName()); ?></h5>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </section>
        <!--speaker section end -->
        
        <!--brands section -->
        <section class="bg-gray pt100 pb100">
            <div class="container">
                <div class="section_title mb50">
                    <h3 class="title">
                        Nos partenaires
                    </h3>
                </div>
                <div class="brand_carousel owl-carousel">
                    <div class="brand_item text-center">
                        <img src="/img/brands/b1.png" alt="brand">
                    </div>
                    <div class="brand_item text-center">
                        <img src="/img/brands/b2.png" alt="brand">
                    </div>
        
                    <div class="brand_item text-center">
                        <img src="/img/brands/b3.png" alt="brand">
                    </div>
                    <div class="brand_item text-center">
                        <img src="/img/brands/b4.png" alt="brand">
                    </div>
                    <div class="brand_item text-center">
                        <img src="/img/brands/b5.png" alt="brand">
                    </div>
                </div>
            </div>
        </section>
        <!--brands section end-->
        <?php echo $__env->make('public.partials.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>