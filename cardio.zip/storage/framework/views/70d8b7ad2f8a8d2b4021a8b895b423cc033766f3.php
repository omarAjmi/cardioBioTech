<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <?php if(Session::has('success')): ?>
                    <div class="sufee-alert alert with-close alert-primary alert-dismissible fade show">
                        <span class="badge badge-pill badge-primary">Success</span>
                            <?php echo e(Session::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
                <div class="">
                    <div class="col-md-12">
                        <!-- DATA TABLE -->
                        <?php if($participations->isnotEmpty()): ?>
                            <div class="table-responsive table-responsive-data2 ">
                                <table class="table table-data2" id="table_id">
                                    <div class="card">
                                    <thead class="card-header">
                                        <tr>
                                            <th>Date</th>
                                            <th>titre</th>
                                            <th>Participant</th>
                                            <th>Fichier</th>
                                            <th>affiliation</th>
                                            <th>autheurs</th>
                                            <th>status</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $participations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($part->created_at->diffForHumans()); ?></td>
                                                <td> <span style="word-break: break-word;"><?php echo e($part->title); ?></span></td>
                                                <td><a href="<?php echo e(route('profile', [$part->participant->id])); ?>"><?php echo e($part->participant->getFullName()); ?></a>
                                                </td>
                                                <td class="process"><a href="<?php echo e(route('participation.download', [
                                                                                                            $part->event_id,
                                                                                                            $part->id
                                                                                                            ])); ?>" target="_blank"><?php echo e($part->file_name); ?></a>
                                                </td>
                                                <td style="max-width: 50px"><span style="word-break: break-word;"><?php echo e($part->affiliation); ?></span></td>
                                                <td style="max-width: 50px"><span style="word-break: break-word;"><?php echo e($part->authors); ?></span></td>
                                                <td>
                                                    <?php if($part->confirmation): ?>
                                                        <span class="status--process">confirmée</span>
                                                    <?php else: ?>
                                                        <span class="status--denied">en attente</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td >
                                                    <div  style="margin-left:  50%">
                                                        <?php if($part->confirmation): ?>
                                                            <input type="hidden" name="_method" value="DELETE">
                                                            <button type="submit" class="item"style="border-radius: 50%;background: #E5E5E5;width: 30px;height: 30px"  >
                                                                <i class="zmdi zmdi-delete" ></i>
                                                            </button>
                                                       <?php else: ?>
                                                            <form action="<?php echo e(route('participation.confirm',[ $part->event_id,
                                                                                                             $part->id
                                                                                                            ])); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="_method" value="PUT">
                                                                <button type="submit" class="item" style="border-radius: 50%;background: #E5E5E5;width: 30px;height: 30px"  >
                                                                    <i class="zmdi zmdi-check-circle"></i>
                                                                </button>
                                                            </form>
                                                            <form action="<?php echo e(route('participation.refuse',[ $part->event_id,
                                                                                                             $part->id
                                                                                                            ])); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="_method" value="DELETE">
                                                                <button type="submit" class="item"  style="border-radius: 50%;background: #E5E5E5;width: 30px;height: 30px" >
                                                                    <i class="zmdi zmdi-delete" style=""></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </div>
                                </table>
                            </div>
                            <?php else: ?>
                            <div class="alert alert-info"> <strong>Info!</strong>Pas de Participations</div>
                            <?php endif; ?>
                    </div>
                </div>
    
              
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>