<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">                    
                    <div class="col-lg-10">
                        <div class="card">
                            <div class="card-header">
                                <strong>modifier L' Évènement</strong>
                            </div>
                            <div class="card-body card-block">
                                <form action="<?php echo e(route('admin.updateEvent', $event->id)); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="PUT">
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="title" class=" form-control-label"> Titre</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input id="title" name="title" placeholder="titre" class="form-control" type="text" <?php if(old('title')): ?>
                                                                                value="<?php echo e(old('title')); ?>"
                                                                                <?php else: ?>
                                                                                value="<?php echo e($event->title); ?>"
                                                                            <?php endif; ?>>
                                            <?php if($errors->has('title')): ?>
                                                <small class="form-text  status--denied"><?php echo e($errors->first('title')); ?></small>
                                            <?php else: ?>
                                                <small class="form-text text-muted"> Titre officiel d'événement</small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="title" class=" form-control-label"> Abbreviation</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input id="abbreviation" name="abbreviation" placeholder="abbreviation" class="form-control" type="text" <?php if(old('abbreviation')): ?>
                                                            value="<?php echo e(old('abbreviation')); ?>"
                                                        <?php else: ?>
                                                            value="<?php echo e($event->abbreviation); ?>"
                                                        <?php endif; ?>>
                                            <?php if($errors->has('abbreviation')): ?>
                                            <small class="form-text status--denied"> <?php echo e($errors->first('abbreviation')); ?></small>
                                            <?php else: ?>
                                            <small class="form-text text-muted"> Abbreviation d'événement</small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="program" class=" form-control-label">Fichier du programme</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input id="program" name="program" class="form-control-file"
                                                type="file" <?php if(old('program')): ?>
                                                                value="<?php echo e(old('program')); ?>"
                                                            <?php else: ?>
                                                                value="<?php echo e($event->program); ?>"
                                                            <?php endif; ?> accept="application/pdf, application/docx">
                                            <small class="form-text text-muted"></small>
                                            <?php if($errors->has('program')): ?>
                                                <small class="form-text status--denied"><?php echo e($errors->first('program')); ?></small>
                                            <?php else: ?>
                                                <small class="form-text text-muted"> fichier doit être de type (pdf, docx)</small>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="program" class=" form-control-label">Poster du programme</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input id="flyer" name="flyer" class="form-control-file"
                                                   type="file" value="<?php echo e(old('flyer')); ?>" accept="image/jpeg,image/png,image/jpg">
                                            <small class="form-text text-muted"></small>
                                            <?php if($errors->has('flyer')): ?>
                                                <small class="form-text status--denied"><?php echo e($errors->first('flyer')); ?></small>
                                            <?php else: ?>
                                                <small class="form-text text-muted"> fichier doit être de type (jpg, jpeg, png)</small>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                           <label for="organiser" class=" form-control-label"> Organisateur</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input id="organiser" name="organiser" placeholder="Organisateur" class="form-control" type="text"
                                                            <?php if(old('organiser')): ?>
                                                                value="<?php echo e(old('organiser')); ?>"
                                                            <?php else: ?>
                                                                value="<?php echo e($event->organiser); ?>"
                                                            <?php endif; ?>>
                                            <?php if($errors->has('organiser')): ?>
                                                <small class="form-text  status--denied"><?php echo e($errors->first('organiser')); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="about   " class=" form-control-label">A propos</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <textarea name="about" id="about" rows="9" placeholder="introduction qui apparaîtra sur la page d'accueil publique..." class="form-control"><?php echo e($event->about); ?></textarea>
                                            <?php if($errors->has('about')): ?>
                                                <small class="form-text status--denied"><?php echo e($errors->first('about')); ?></small>
                                            <?php else: ?>                                                
                                                <small class="form-text text-muted"> S'affichera aux page publique</small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="sliders" class=" form-control-label">Sélectionnez les curseurs d'événement</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input id="sliders" name="sliders[]" multiple="" class="form-control-file"
                                                type="file" <?php if(old('sliders[]')): ?>
                                                                value="<?php echo e(old('sliders[]')); ?>"
                                                            <?php endif; ?> accept="image/jpeg,image/png,image/jpg">
                                            
                                            <?php for($i = 0; $i < 5; $i++): ?>
                                                <?php if($errors->any('sliders.'.$i)): ?>
                                                    <small class="form-text status--denied"><?php echo e($errors->first('sliders.'.$i)); ?></small>
                                                    <?php break; ?>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                            <?php if($errors->any('sliders')): ?>
                                                <small class="form-text status--denied"><?php echo e($errors->first('sliders')); ?></small>
                                            <?php else: ?>
                                                 <small class="form-text text-muted"> 4 images aux plus</small>
                                            <?php endif; ?>                                           
                                        </div>
                                    </div>
                                      <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="sliders" class=" form-control-label">Gouvernerat :</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input name="state" placeholder="Governorat" class="form-control" type="text" <?php if(old('state')): ?>
                                                                                                                            value="<?php echo e(old('state')); ?>"
                                                                                                                        <?php else: ?>
                                                                                                                            value="<?php echo e($event->address->state); ?>"
                                                                                                                        <?php endif; ?>>
                                             <?php if($errors->has('state')): ?>
                                                <small class="form-text status--denied"><?php echo e($errors->first('state')); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                      <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="sliders" class=" form-control-label">Ville :</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                              <input name="city" placeholder="Ville" class="form-control" type="text" <?php if(old('city')): ?>
                                                                                                                        value="<?php echo e(old('city')); ?>"
                                                                                                                    <?php else: ?>
                                                                                                                        value="<?php echo e($event->address->city); ?>"
                                                                                                                    <?php endif; ?>>
                                            <?php if($errors->has('city')): ?>
                                                <small class="form-text status--denied"><?php echo e($errors->first('city')); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                       <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="sliders" class=" form-control-label">Rue :</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <input name="street" placeholder="Rue" class="form-control" type="text" <?php if(old('street')): ?>
                                                                                                                        value="<?php echo e(old('street')); ?>"
                                                                                                                    <?php else: ?>
                                                                                                                        value="<?php echo e($event->address->street); ?>"
                                                                                                                    <?php endif; ?>>
                                            <?php if($errors->has('street')): ?>
                                                <small class="form-text status--denied"><?php echo e($errors->first('street')); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="sliders" class=" form-control-label"> Date finale des <br> propositions</label>
                                        </div>
                                        <div class=" col-12 col-md-9 
                                         " >
                                           <div class="input-group " id="datetimepicker1">
                                            <input name="dead_line" type='text' id="date" class="form-control" <?php if(old('dead_line')): ?>
                                                                                                        value="<?php echo e(old('dead_line')); ?>"
                                                                                                    <?php else: ?>
                                                                                                        value="<?php echo e($event->dead_line); ?>"
                                                                                                    <?php endif; ?>/>
                                            <span class="input-group-addon">
                                                <span class="fas fa-calendar-alt"></span>
                                            </span>
                                            </div>
                                             <?php if($errors->has('dead_line')): ?>
                                            <small class="form-text status--denied"><?php echo e($errors->first('dead_line')); ?></small>
                                        <?php endif; ?>
                                        </div>
                                       
                                    </div>
                                     <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="start_date" class=" form-control-label"> De</label>
                                        </div>
                                        <div class="col-4 col-md-4 "  >
                                            <div class="input-group " id="datetimepicker2">
                                             <input name="start_date" type='text' class="form-control" <?php if(old('start_date')): ?>
                                                                                                        value="<?php echo e(old('start_date')); ?>"
                                                                                                    <?php else: ?>
                                                                                                        value="<?php echo e($event->start_date); ?>"
                                                                                                    <?php endif; ?>>
                                            <span class="input-group-addon">
                                                <span class="fas fa-calendar-alt"></span>
                                            </span>
                                            </div>
                                             <?php if($errors->has('start_date')): ?>
                                            <small class="form-text status--denied"><?php echo e($errors->first('start_date')); ?></small>
                                        <?php endif; ?>
                                        
                                        </div>
                                       
                                        <div class="col-1">
                                           <label>A</label> 
                                        </div>
                                        <div class="col-4 col-md-4">
                                            <div class="input-group " id="datetimepicker3">
                                             <input name="end_date" type='text' class="form-control" <?php if(old('end_date')): ?>
                                                                                                        value="<?php echo e(old('end_date')); ?>"
                                                                                                    <?php else: ?>
                                                                                                        value="<?php echo e($event->end_date); ?>"
                                                                                                    <?php endif; ?>>
                                            <span class="input-group-addon">
                                                <span class="fas fa-calendar-alt"></span>
                                            </span>
                                            </div>
                                             <?php if($errors->has('end_date')): ?>
                                            <small class="form-text status--denied"><?php echo e($errors->first('end_date')); ?></small>
                                        <?php endif; ?>
                                        </div>
                                       
                                    </div>
                                    <br>
                                    <hr>
                                   
                                    <div class="pull-right">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="zmdi zmdi-dot-circle-o"></i> Mettre a jour l'evenement
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="zmdi zmdi-ban"></i> Reset
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>