<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <a class="btn btn-primary pull-right" href="<?php echo e(route('commitees.addMember', $commitee->event_id)); ?>">Ajouter un membre</a>
                <div class="row">
                    <?php if($commitee->members->isEmpty()): ?>
                        <div class="alert alert-info"> <strong>Info!</strong> Pas de membres pour le moment</div>
                    <?php else: ?>
                        <?php $__currentLoopData = $commitee->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3" style="display: inline-block;">
                            <div class="card">
                                <img style="max-height: 140px;max-width: 300px;" class="card-img-top" src="<?php echo e($member->data->photo); ?>" alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title mb-3"><?php echo e($member->data->getFullName()); ?></h5>
                                    <form action="<?php echo e(route('commitees.removeMember',[
                                        'id'=> $member->commitee_id,
                                        'commitee_id'=>$member->commitee->id,
                                        'member_id'=>$member->data->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="_method" value="DELETE">
                                        <button type="submit" class="item pull-right"  style="border-radius: 50%;background: #E5E5E5;width: 30px;height: 30px;margin-top: -13%" >
                                            <i class="zmdi zmdi-delete" style=""></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>