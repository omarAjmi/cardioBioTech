<section class="pb100">
    <div class="container" id="speakers">
        <div class="section_title mb50">
            <h3 class="title">
                Poster du programme
            </h3>
        </div>
    </div>
    <div class="row justify-content-center no-gutters">
        <div class="col-md-5 col-sm-6">
            <div class="speaker_box">
                <div class="speaker_img">
                    <img src="<?php echo e($event->flyer); ?>" alt="Poster">
                </div>
            </div>
        </div>
    </div>
</section>