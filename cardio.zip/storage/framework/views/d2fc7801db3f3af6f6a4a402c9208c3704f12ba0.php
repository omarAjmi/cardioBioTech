<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                    <div class="col-md-12 ">
                        <!-- DATA TABLE -->
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success" role="alert">
                                <span class="badge badge-pill badge-primary">Succès</span>
                                <?php echo e(Session::get('success')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Fermer">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                        <?php endif; ?>
                         <a class="btn btn-primary pull-right" href="<?php echo e(route('admin.newEvent')); ?>">Creer un nouvel évènement</a>
                        <h3 class="title-5 m-b-35">Évènements</h3>
                       
                        <?php if($events->isEmpty()): ?>
                            <div class="alert alert-info"> <strong>Info!</strong>  Pas encore des évènnements</div>
                        <?php else: ?>

                            <div class="table-responsive table-responsive-data2 ">
                                
                                <table class="table table-data2" id="table_id">
                                    <div class="card">
                                    <thead class="card-header">
                                           
                                            <th>abbreviation</th>
                                            <th>titre</th>
                                            <th>programme</th>
                                            <th>début</th>
                                            <th>fin</th>
                                            <th>etat</th>
                                            <th>options</th>
                                            
                                    </thead>
                                    <tbody class="card-body">                                      
                                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="tr-shadow">
                                               
                                                <td><?php echo e($event->abbreviation); ?></td>
                                                <td>
                                                    <span class="block-email"><?php echo e($event->title); ?></span>
                                                </td>
                                                <td class="desc"><a href="<?php echo e(route('downloadFileEvent', [
                                                    'id'=>$event->id,
                                                    'filename'=>$event->getProgramFileName()
                                                    ])); ?>" target="_blank"><?php echo e($event->getProgramFileName()); ?></a>
                                                        
                                                    </td>
                                                <td><?php echo e($event->start_date->format('l j F Y H:i:s')); ?></td>
                                                <td><?php echo e($event->end_date->format('l j F Y H:i:s')); ?></td>
                                                
                                                <?php if($event->start_date < now()): ?>
                                                    <td>
                                                        <span class="status--denied">dépasser</span>
                                                    </td>
                                                <?php else: ?>
                                                    <td>
                                                        <span class="status--process">en attente</span>
                                                    </td>
                                                <?php endif; ?>
                                                <td>
                                                    <div class="table-data-feature">
                                                        
                                                        <a href="<?php echo e(route('admin.previewEvent', [$event->id])); ?>">
                                                            <button class="item"  data-original-title="Edit">
                                                                <i class="zmdi zmdi-edit"></i>
                                                            </button>
                                                        </a>&nbsp;
                                                        <form action="<?php echo e(route('admin.deleteEvent', [$event->id])); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="_method" value="DELETE">
                                                            <button type="submit" class="item"  data-original-title="Delete">
                                                                <i class="zmdi zmdi-delete" style=""></i>
                                                            </button>
                                                        </form>
                                                    </div>
                                                </td>
                                           </tr>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                     </div>
                                </table>
                               
                            </div>
                        <?php endif; ?>
                    </div>
               
   
            </div>
        </div>
    </div> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>