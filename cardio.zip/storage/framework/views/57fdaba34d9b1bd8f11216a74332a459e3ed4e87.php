<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">                    
                    <div class="col-lg-10">
                        <div class="card">
                            <div class="card-header">
                                Évènnement <strong><?php echo e($event->abbreviation); ?></strong> / Ajouter Membres Aux Commitée
                            </div>
                            <div class="card-body card-block">
                                <form action="<?php echo e(route('commitees.addMember', [$event->id])); ?>" method="post" class="form-horizontal">
                                    <?php echo csrf_field(); ?>
                                    
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label for="member_search" class=" form-control-label">Sélectionnez un membre a ajouter</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <select name="member" id="member" class="form-control" style="height: 100%" >
                                                <?php if($members->isNotEmpty()): ?>
                                                    <option selected disabled>choisissez un membre</option>
                                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($member->id); ?>"><?php echo e($member->getFullName()); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <option selected disabled>Aucun member pour le moment</option>
                                                <?php endif; ?>                                                
                                            </select>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="pull-right" >
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="zmdi zmdi-dot-circle-o"></i> Ajouter
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="zmdi zmdi-ban"></i> Annuler
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>