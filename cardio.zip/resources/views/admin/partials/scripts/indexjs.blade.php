<!-- Jquery JS-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<!-- Bootstrap JS-->
<script src="/admin_site/vendor/bootstrap-4.1/popper.min.js"></script>
{{-- <script src="/admin_site/vendor/bootstrap-4.1/bootstrap.js"></script> --}}

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.3/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.14.30/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
	    jQuery(document).ready(function ($) {
        console.log("hhh");
$(function () {
                $('#datetimepicker1').datetimepicker({
                    defaultDate: new Date(),
                    format: 'YYYY-MM-DD HH:mm:ss',

                    sideBySide: true,

                });
                 $('#datetimepicker2').datetimepicker({
                    defaultDate: new Date(),
                    format: 'YYYY-MM-DD HH:mm:ss',

                    sideBySide: true,

                });
                  $('#datetimepicker3').datetimepicker({
                    defaultDate: new Date(),
                    format: 'YYYY-MM-DD HH:mm:ss',

                    sideBySide: true,

                });
                   
            });
           });
         
           
</script>
<!-- Vendor JS       -->
<script src="/admin_site/vendor/slick/slick.min.js">
</script>
<script src="/admin_site/vendor/wow/wow.min.js"></script>
<script src="/admin_site/vendor/animsition/animsition.min.js"></script>
<script src="/admin_site/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="/admin_site/vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="/admin_site/vendor/counter-up/jquery.counterup.min.js">
</script>
<script src="/admin_site/vendor/circle-progress/circle-progress.min.js"></script>
<script src="/admin_site/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="/admin_site/vendor/chartjs/Chart.bundle.min.js"></script>
<script src="/admin_site/vendor/select2/select2.min.js"></script>

<!-- Main JS-->
<script src="/admin_site/js/main.js"></script>