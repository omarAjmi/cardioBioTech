<!-- ========== Favicon Ico ========== -->
<!--<link rel="icon" href="fav.ico">-->
<!-- ========== STYLESHEETS ========== -->
<!-- Bootstrap CSS -->
<link href="/css/bootstrap.min.css" rel="stylesheet">
<!-- Fonts Icon CSS -->
<link href="/css/font-awesome.min.css" rel="stylesheet">
<link href="/css/et-line.css" rel="stylesheet">
<link href="/css/ionicons.min.css" rel="stylesheet">
<!-- Carousel CSS -->
<link href="/css/owl.carousel.min.css" rel="stylesheet">
<link href="/css/owl.theme.default.min.css" rel="stylesheet">
<!-- Animate CSS -->
<link rel="stylesheet" href="/css/animate.min.css">
<!-- Custom styles for this template -->
<link href="/css/main.css" rel="stylesheet">



<!--===============================================================================================-->

<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="/css-hamburgers/hamburgers.min.css">

